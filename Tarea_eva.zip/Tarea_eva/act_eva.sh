#!/bin/bash

cont=0
lineasmax=`cat usuario.txt | wc -l`
read -p "Dime el nombre del usuario: " nomusu

for i in `seq 0 $lineasmax`;do
	nombres=`cat usuario.txt | head -$i | tail -1 | awk '{print $1}'`
	if [ "$nomusu" = "$nombres" ]; then
		cont=$(($cont+1))
	fi
done

if [ $cont -eq 0 ]; then
	echo "El usuario no se ha logueado"
else
	echo "El usuario se ha logueado: $cont veces"
fi


read -p "Dime un mes del año: " mes
cont2=0

for i in `seq 0 $lineasmax`;do
        meses=`cat usuario.txt | head -$i | tail -1 | awk '{print $3}'`
	diasMes=`cat usuario.txt | head -$i | tail -1 | awk '{print $2}'`
        if [ "$meses" = "$mes" ]; then
              	echo "$diasMes"
        	cont2=$(($cont2+1))
	fi
done

if [ $cont2 -eq 0 ]; then
	echo "0"
fi


read -p "Introduce dia del mes: " diapedido
read -p "Introduce mes del año: " mespedido
cont3=0

for i in `seq 0 $lineasmax`; do
	nombres=`cat usuario.txt | head -$i | tail -1 | awk '{print $1}'`
	meses=`cat usuario.txt | head -$i | tail -1 | awk '{print $3}'`
        diasMes=`cat usuario.txt | head -$i | tail -1 | awk '{print $2}'`
	if [ "$diapedido" = "$diasMes" ]; then
		if [ "$mespedido" = "$meses" ]; then
			echo "$nombres se conecto el $diapedido de $mespedido"
			cont3=$(($cont3+1))
		fi
	fi
done
	if [ $cont3 -eq 0 ]; then
		echo "no se ha concetado nadie el dia $diapedido de $mespedido"
	fi



read -p "Vuelve a introducir el usuario: " nomusu2
cont3=0
diaif2=""
mesif2=""

for i in `seq 0 $lineasmax`; do
	nombres=`cat usuario.txt | head -$i | tail -1 | awk '{print $1}'`
	if [ "$nomusu2" = "$nombres" ]; then
        	nombresif=`cat usuario.txt | head -$i | tail -1 | awk '{print $1}'`

		diaif=`cat usuario.txt | head -$i | tail -1 | awk '{print $2}'`
		diaif2=$diaif

		mesif=`cat usuario.txt | head -$i | tail -1 | awk '{print $3}'`
		mesif2=$mesif
                cont3=$(($cont3+1))
        fi
done

if [ $cont3 -eq 0 ]; then
	echo "No se ha logueado"
else
	echo "La ultima conexion de $nomusu2 es el: $diaif2 de $mesif2"

fi

